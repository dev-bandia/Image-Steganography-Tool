# Image Steganography Tool

## Overview
The **Image Steganography Tool** allows users to embed and retrieve hidden images within other images. This project was developed with the help of ChatGPT. AI Rules!

## Features
- Embed one or more images inside a container image.
- Retrieve hidden images using a unique key.
- Generates unique output filenames with timestamps for better organization.
- Provides a smooth loading animation during embedding and retrieval processes.
- Easily copy and paste keys for embedded images.
- Outputs all embedding keys on separate lines for better readability.

## How to Use

Run **"Image Steganography v1.4 - Dev Bandia.exe"**.

> **Note**: You may need to disable your antivirus software if it flags the executable. I promise it’s malware-free!

If you prefer to run the code or verify it yourself, check out the "main.py" and "steganography.py" files in the repository.

### Embedding an Image
1. Select the container image where you want to hide other images.
2. Choose one or more images you want to hide.
3. Select the folder to save the output container image.
4. Copy the key for each hidden image—this will be needed to retrieve the images later.

### Retrieving an Image
1. Paste the key corresponding to the hidden image.
2. Select the container image.
3. Choose the output folder where you want to save the retrieved image.

## Notes
- Two sample container images are included:
  1. The first image is 10000 x 10000 pixels.
  2. The second image is 20000 x 13333, which is good for testing large embeddings!
  
  Feel free to try them out and share hidden images with your friends. All you need is the container image and the key!

- **Patience Warning**: Embedding or retrieving images can take a while, especially with large container images or many hidden images. Just give it some time!

## Have Fun!
Enjoy using the tool to share secret messages with your friends, and thanks for trying it out! <3
